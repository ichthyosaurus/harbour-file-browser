<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>AboutPage</name>
    <message>
        <location filename="../qml/pages/AboutPage.qml" line="19"/>
        <source>Public Domain</source>
        <translation>Public Domain</translation>
    </message>
</context>
<context>
    <name>ConsoleModel</name>
    <message>
        <location filename="../consolemodel.cpp" line="101"/>
        <source>** crashed</source>
        <translation>** abgestürzt</translation>
    </message>
    <message>
        <location filename="../consolemodel.cpp" line="104"/>
        <source>** error: %1</source>
        <translation>** Fehler: %1</translation>
    </message>
    <message>
        <location filename="../consolemodel.cpp" line="113"/>
        <source>** error</source>
        <translation>** Fehler</translation>
    </message>
</context>
<context>
    <name>CreateFolderDialog</name>
    <message>
        <source>Create Folder</source>
        <translation type="vanished">Ordner erstellen</translation>
    </message>
    <message>
        <location filename="../qml/pages/CreateFolderDialog.qml" line="30"/>
        <source>Create</source>
        <translation>Erstellen</translation>
    </message>
    <message>
        <location filename="../qml/pages/CreateFolderDialog.qml" line="36"/>
        <source>Create a new folder under</source>
        <translation>Neuen Ordner erstellen unter</translation>
    </message>
    <message>
        <location filename="../qml/pages/CreateFolderDialog.qml" line="48"/>
        <location filename="../qml/pages/CreateFolderDialog.qml" line="49"/>
        <source>Folder name</source>
        <translation>Ordnername</translation>
    </message>
</context>
<context>
    <name>DirPopup</name>
    <message>
        <location filename="../qml/components/DirPopup.qml" line="22"/>
        <source>Root (%1)</source>
        <translation>Stammverzeichnis (%1)</translation>
    </message>
    <message>
        <location filename="../qml/components/DirPopup.qml" line="25"/>
        <source>Root</source>
        <translation>Stammverzeichnis</translation>
    </message>
    <message>
        <location filename="../qml/components/DirPopup.qml" line="32"/>
        <source>SD Card (%1)</source>
        <translation>SD-Karte (%1)</translation>
    </message>
    <message>
        <location filename="../qml/components/DirPopup.qml" line="35"/>
        <source>SD Card</source>
        <translation>SD-Karte</translation>
    </message>
    <message>
        <location filename="../qml/components/DirPopup.qml" line="81"/>
        <source>Android Storage not found</source>
        <translation>Android-Speicher nicht gefunden</translation>
    </message>
    <message>
        <location filename="../qml/components/DirPopup.qml" line="93"/>
        <source>SD Card not found</source>
        <translation>SD-Karte nicht gefunden</translation>
    </message>
    <message>
        <location filename="../qml/components/DirPopup.qml" line="100"/>
        <source>Home</source>
        <translation>Benutzerverzeichnis</translation>
    </message>
    <message>
        <location filename="../qml/components/DirPopup.qml" line="104"/>
        <source>Android Storage</source>
        <translation>Android-Speicher</translation>
    </message>
</context>
<context>
    <name>DirectoryPage</name>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="40"/>
        <source>Settings</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="44"/>
        <source>Create Folder</source>
        <translation>Ordner erstellen</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="55"/>
        <source>Search</source>
        <translation>Suchen</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="60"/>
        <source>Paste</source>
        <translation>Einfügen</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="71"/>
        <location filename="../qml/pages/DirectoryPage.qml" line="78"/>
        <source>Copying</source>
        <translation>Kopiere</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="71"/>
        <location filename="../qml/pages/DirectoryPage.qml" line="78"/>
        <source>Moving</source>
        <translation>Verschiebe</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="201"/>
        <location filename="../qml/pages/DirectoryPage.qml" line="202"/>
        <location filename="../qml/pages/DirectoryPage.qml" line="275"/>
        <location filename="../qml/pages/DirectoryPage.qml" line="277"/>
        <source>Deleting</source>
        <translation>Lösche</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="217"/>
        <source>Cut</source>
        <translation>Ausschneiden</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="221"/>
        <source>Copy</source>
        <translation>Kopieren</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="225"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="232"/>
        <source>Properties</source>
        <translation>Eigenschaften</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="245"/>
        <source>No files</source>
        <translation>Keine Dateien</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="319"/>
        <source>Trying to move between phone and SD Card? It does not work, try copying.</source>
        <translation>Verschiebst Du von Telefon auf SD-Karte oder umgekehrt? Das funktioniert nicht, probiere es mit Kopieren.</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="321"/>
        <source>Perhaps the storage is full?</source>
        <translation>Vielleicht ist kein Speicherplatz mehr frei?</translation>
    </message>
</context>
<context>
    <name>Engine</name>
    <message>
        <location filename="../engine.cpp" line="110"/>
        <source>Destination does not exist</source>
        <translation>Ziel existiert nicht</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="121"/>
        <source>Cannot overwrite itself</source>
        <translation>Kann sich nicht selbst überschreiben</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="127"/>
        <source>Cannot move/copy to itself</source>
        <translation>Kann nicht in sich selbst verschoben/kopiert werden</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="102"/>
        <source>No files to paste</source>
        <translation>Keine Dateien zum Einfügen</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="272"/>
        <source>File does not exist</source>
        <translation>Datei existiert nicht</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="274"/>
        <source>Broken symbolic link</source>
        <translation>Symbolische Verknüpfung defekt</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="279"/>
        <source>Cannot read this type of file</source>
        <translation>Kann dieses Dateiformat nicht lesen</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="285"/>
        <source>No permission to read the file</source>
        <translation>Keine Berechtigung zum Lesen der Datei</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="289"/>
        <location filename="../engine.cpp" line="295"/>
        <source>Error reading file</source>
        <translation>Fehler beim Lesen der Datei</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="298"/>
        <source>Empty file</source>
        <translation>Leere Datei</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="324"/>
        <location filename="../engine.cpp" line="325"/>
        <source>--- Binary file preview clipped at %1 kB ---</source>
        <translation>--- Vorschau für Binärdatei, abgeschnitten nach %1 kB</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="344"/>
        <source>--- Text file preview clipped at %1 lines ---</source>
        <translation>--- Vorschau fürTextdatei, abgeschnitten nach %1 Zeilen</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="346"/>
        <source>--- Text file preview clipped at %1 kB ---</source>
        <translation>--- Vorschau fürTextdatei, abgeschnitten nach %1 kB</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="358"/>
        <source>No permissions to create %1</source>
        <translation>Keine Berechtigung zum Erstellen von %1</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="376"/>
        <source>Cannot rename %1</source>
        <translation>Kann %1 nicht umbenennen</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="399"/>
        <source>Cannot change permissions</source>
        <translation>Kann Berechtigungen nicht anpassen</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="360"/>
        <source>Cannot create folder %1</source>
        <translation>Kann Verzeichnis %1 nicht erstellen</translation>
    </message>
</context>
<context>
    <name>FileData</name>
    <message>
        <location filename="../filedata.cpp" line="102"/>
        <source>File does not exist</source>
        <translation>Datei existiert nicht</translation>
    </message>
    <message>
        <location filename="../filedata.cpp" line="136"/>
        <source>block device</source>
        <translation>Block Device</translation>
    </message>
    <message>
        <location filename="../filedata.cpp" line="140"/>
        <source>character device</source>
        <translation>Character Device</translation>
    </message>
    <message>
        <location filename="../filedata.cpp" line="144"/>
        <source>pipe</source>
        <translation>Pipe</translation>
    </message>
    <message>
        <location filename="../filedata.cpp" line="148"/>
        <source>socket</source>
        <translation>Socket</translation>
    </message>
    <message>
        <location filename="../filedata.cpp" line="152"/>
        <source>folder</source>
        <translation>Ordner</translation>
    </message>
    <message>
        <location filename="../filedata.cpp" line="157"/>
        <source>unknown</source>
        <translation>unbekannt</translation>
    </message>
    <message>
        <location filename="../filedata.cpp" line="180"/>
        <source>Image Size</source>
        <translation>Bildgröße</translation>
    </message>
</context>
<context>
    <name>FileModel</name>
    <message>
        <location filename="../filemodel.cpp" line="71"/>
        <source>dir-link</source>
        <translation>dir-link</translation>
    </message>
    <message>
        <location filename="../filemodel.cpp" line="72"/>
        <source>dir</source>
        <translation>dir</translation>
    </message>
    <message>
        <location filename="../filemodel.cpp" line="300"/>
        <location filename="../filemodel.cpp" line="338"/>
        <source>Folder does not exist</source>
        <translation>Ordner existiert nicht</translation>
    </message>
    <message>
        <location filename="../filemodel.cpp" line="304"/>
        <location filename="../filemodel.cpp" line="344"/>
        <source>No permission to read the folder</source>
        <translation>Keine Berechtigung, den Ordner zu lesen</translation>
    </message>
</context>
<context>
    <name>FilePage</name>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="26"/>
        <source>Install launched</source>
        <translation>Installation gestartet</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="27"/>
        <source>If nothing happens, then the package is probably faulty.</source>
        <translation>Wenn nichts passiert, ist das Paket vermutlich fehlerhaft.</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="31"/>
        <source>Open successful</source>
        <translation>Öffnen erfolgreich</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="32"/>
        <source>Sometimes the application stays in the background</source>
        <translation>Manchmal bleibt die Anwendung im Hintergrund</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="34"/>
        <source>Internal error</source>
        <translation>Interner Fehler</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="37"/>
        <source>File not found</source>
        <translation>Datei nicht gefunden</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="40"/>
        <source>No application to open the file</source>
        <translation>Keine Anwendung zum Öffnen der Datei</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="41"/>
        <source>xdg-open found no preferred application</source>
        <translation>xdg-open konnte keine bevorzugte Anwendung finden</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="43"/>
        <source>Action failed</source>
        <translation>Aktion fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="46"/>
        <source>xdg-open not found</source>
        <translation>xdg-open nicht gefunden</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="49"/>
        <source>xdg-open crash?</source>
        <translation>xdg-open abgestürzt?</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="52"/>
        <source>xdg-open error</source>
        <translation>xdg-open Fehler</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="65"/>
        <source>Change Permissions</source>
        <translation>Berechtigungen ändern</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="78"/>
        <source>Rename</source>
        <translation>Umbenennen</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="92"/>
        <source>View Contents</source>
        <translation>Inhalt ansehen</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="99"/>
        <source>Install</source>
        <translation>Installieren</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="99"/>
        <source>Open</source>
        <translation>Öffnen</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="103"/>
        <source>File cannot be opened</source>
        <translation>Datei kann nicht geöffnet werden</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="104"/>
        <source>This type of file cannot be opened.</source>
        <translation>Dieser Dateityp kann nicht geöffnet werden.</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="112"/>
        <source>Go to Target</source>
        <translation>Zu Ziel gehen</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="236"/>
        <source>Location</source>
        <translation>Ort</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="240"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="242"/>
        <source>Link to %1</source>
        <translation>Link zu %1</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="246"/>
        <source>Size</source>
        <translation>Größe</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="250"/>
        <source>Permissions</source>
        <translation>Berechtigungen</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="254"/>
        <source>Owner</source>
        <translation>Besitzer</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="258"/>
        <source>Group</source>
        <translation>Gruppe</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="262"/>
        <source>Last modified</source>
        <translation>Zuletzt geändert</translation>
    </message>
    <message>
        <source>Created</source>
        <translation type="vanished">Erstellt</translation>
    </message>
</context>
<context>
    <name>FileWorker</name>
    <message>
        <location filename="../fileworker.cpp" line="20"/>
        <location filename="../fileworker.cpp" line="36"/>
        <location filename="../fileworker.cpp" line="53"/>
        <source>File operation already in progress</source>
        <translation>Dateivorgang noch nicht abgeschlossen</translation>
    </message>
    <message>
        <location filename="../fileworker.cpp" line="91"/>
        <source>Empty filename</source>
        <translation>Leerer Dateiname</translation>
    </message>
    <message>
        <location filename="../fileworker.cpp" line="102"/>
        <source>File not found</source>
        <translation>Datei nicht gefunden</translation>
    </message>
    <message>
        <location filename="../fileworker.cpp" line="115"/>
        <source>Folder delete failed</source>
        <translation>Ordner konnte nicht gelöscht werden</translation>
    </message>
    <message>
        <location filename="../fileworker.cpp" line="137"/>
        <location filename="../fileworker.cpp" line="188"/>
        <location filename="../fileworker.cpp" line="284"/>
        <location filename="../fileworker.cpp" line="300"/>
        <source>Cancelled</source>
        <translation>Abgebrochen</translation>
    </message>
    <message>
        <location filename="../fileworker.cpp" line="269"/>
        <source>Source folder does not exist</source>
        <translation>Quellordner existiert nicht</translation>
    </message>
    <message>
        <location filename="../fileworker.cpp" line="276"/>
        <source>Cannot create target folder %1</source>
        <translation>Kann Zielordner nicht erstellen %1</translation>
    </message>
</context>
<context>
    <name>OverwriteDialog</name>
    <message>
        <location filename="../qml/pages/OverwriteDialog.qml" line="27"/>
        <source>Replace?</source>
        <translation>Ersetzen?</translation>
    </message>
    <message>
        <location filename="../qml/pages/OverwriteDialog.qml" line="28"/>
        <source>Replace</source>
        <translation>Ersetzen</translation>
    </message>
    <message>
        <location filename="../qml/pages/OverwriteDialog.qml" line="32"/>
        <source>These files or folders already exist:</source>
        <translation>Diese Dateien oder Ordner existieren schon:</translation>
    </message>
</context>
<context>
    <name>PermissionsDialog</name>
    <message>
        <source>Change Permissions</source>
        <translation type="vanished">Berechtigungen ändern</translation>
    </message>
    <message>
        <location filename="../qml/pages/PermissionsDialog.qml" line="56"/>
        <source>Change</source>
        <translation>Ändern</translation>
    </message>
    <message>
        <location filename="../qml/pages/PermissionsDialog.qml" line="62"/>
        <source>Change permissions for</source>
        <translation>Berechtigungen ändern für</translation>
    </message>
    <message>
        <location filename="../qml/pages/PermissionsDialog.qml" line="82"/>
        <source>Read</source>
        <translatorcomment>Would prefer German &quot;Lesen&quot;, but labels didn&apos;t fit in page layout; so I left English original which should be alright for anyone who knows how to handle file permissions :)</translatorcomment>
        <translation>Read</translation>
    </message>
    <message>
        <location filename="../qml/pages/PermissionsDialog.qml" line="90"/>
        <source>Write</source>
        <translatorcomment>Would prefer German &quot;Schreiben&quot;, but labels didn&apos;t fit in page layout; so I left English original which should be alright for anyone who knows how to handle file permissions :)</translatorcomment>
        <translation>Write</translation>
    </message>
    <message>
        <location filename="../qml/pages/PermissionsDialog.qml" line="97"/>
        <source>Execute</source>
        <translatorcomment>Would prefer German &quot;Ausführen&quot;, but labels didn&apos;t fit in page layout; so I left English original which should be alright for anyone who knows how to handle file permissions :)</translatorcomment>
        <translation>Execute</translation>
    </message>
    <message>
        <location filename="../qml/pages/PermissionsDialog.qml" line="118"/>
        <source>Owner</source>
        <translation>Besitzer</translation>
    </message>
    <message>
        <location filename="../qml/pages/PermissionsDialog.qml" line="156"/>
        <source>Group</source>
        <translation>Gruppe</translation>
    </message>
    <message>
        <location filename="../qml/pages/PermissionsDialog.qml" line="189"/>
        <source>Others</source>
        <translation>Andere</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="120"/>
        <source>Make:%1</source>
        <translation>Hersteller: %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="121"/>
        <source>Model:%1</source>
        <translation>Modell: %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="124"/>
        <source>Date/Time:%1</source>
        <translation>Datum/Zeit: %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="131"/>
        <source>Orientation:%1</source>
        <translation>Ausrichtung: %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="136"/>
        <source>Color/BW:Black and White</source>
        <translation>Farbe/SW:Schwarz und weiß</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="143"/>
        <source>(Strobe light not detected)</source>
        <translation>(Blitzlicht nicht erkannt)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="144"/>
        <source>(Strobe light detected) </source>
        <translation>(Blitzlicht erkannt)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="145"/>
        <source>(Manual)</source>
        <translation>(Manuell)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="146"/>
        <source>(Manual, return light not detected)</source>
        <translation>(Manuell, Quittungslampe nicht erkannt)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="148"/>
        <location filename="../jhead/jhead-api.cpp" line="166"/>
        <source>(Auto)</source>
        <translation>(Auto)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="149"/>
        <source>(Auto, return light not detected)</source>
        <translation>(Auto, Quittungslampe nicht erkannt)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="150"/>
        <source>(Auto, return light detected)</source>
        <translation>(Auto, Quittungslampe erkannt)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="151"/>
        <source>(Red eye reduction mode)</source>
        <translation>(Rote-Augen-Reduzierung)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="152"/>
        <source>(Red eye reduction mode return light not detected)</source>
        <translation>(Rote-Augen-Reduzierung, Quittungslampe nicht erkannt)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="147"/>
        <source>(Manual, return light detected)</source>
        <translation>(Manuell, Quittungslampe erkannt)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="153"/>
        <source>(Red eye reduction mode return light detected)</source>
        <translation>(Rote-Augen-Reduzierung, Quittungslampe erkannt)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="154"/>
        <source>(Manual, red eye reduction mode)</source>
        <translation>(Manuell, Rote-Augen-Reduzierung)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="155"/>
        <source>(Manual, red eye reduction mode, return light not detected)</source>
        <translation>(Manuell, Rote-Augen-Reduzierung, Quittungslampe nicht erkannt)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="156"/>
        <source>(Red eye reduction mode, return light detected)</source>
        <translation>(Rote-Augen-Reduzierung, Quittungslampe erkannt)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="157"/>
        <source>(Auto, red eye reduction mode)</source>
        <translation>(Auto, Rote-Auge-Reduzierung)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="158"/>
        <source>(Auto, red eye reduction mode, return light not detected)</source>
        <translation>(Auto, Rote-Augen-Reduzierung, Quittungslampe nicht erkannt)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="159"/>
        <source>(Auto, red eye reduction mode, return light detected)</source>
        <translation>(Auto, Rote-Augen-Reduzierung, Quittungslampe erkannt)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="161"/>
        <source>Flash:Yes</source>
        <translation>Blitz:ja</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="168"/>
        <source>Flash:No</source>
        <translation>Blitz:nein</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="174"/>
        <source>Focal Length:%1mm</source>
        <translation>Brennweite: %1mm</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="176"/>
        <source>(35mm equivalent: %1mm)</source>
        <translation>(35mm Äquivalent: %1mm)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="183"/>
        <source>Digital Zoom:%1x</source>
        <translation>Digitaler Zoom: %1x</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="187"/>
        <source>CCD Width:%1</source>
        <translation>CCD-Breite: %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="193"/>
        <location filename="../jhead/jhead-api.cpp" line="195"/>
        <source>Exposure Time:%1</source>
        <translation>Belichtungszeit: %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="198"/>
        <source>(1/%1)</source>
        <translation>(1/%1)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="203"/>
        <source>Aperture:f/%1</source>
        <translation>Blende: f/%1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="207"/>
        <source>Focus Distance:Infinite</source>
        <translation>Fokusabstand: unendlich</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="209"/>
        <source>Focus Distance:%1m</source>
        <translation>Fokusabstand: %1m</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="214"/>
        <source>ISO Equivalent:%1</source>
        <translation>ISO-Äquivalent: %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="220"/>
        <source>Exposure Bias:%1</source>
        <translation>Blendenöffnung: %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="225"/>
        <source>White Balance:Manual</source>
        <translation>Weißabgleich: manuell</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="228"/>
        <source>White Balance:Auto</source>
        <translation>Weißabgleich: auto</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="235"/>
        <source>Light Source:Daylight</source>
        <translation>Lichtquelle: Tageslicht</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="238"/>
        <source>Light Source:Fluorescent</source>
        <translation>Lichtquelle: Leuchtstofflampe</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="241"/>
        <source>Light Source:Incandescent</source>
        <translation>Lichtquelle: Glühlampe</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="244"/>
        <source>Light Source:Flash</source>
        <translation>Lichtquelle: Blitz</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="247"/>
        <source>Light Source:Fine weather</source>
        <translation>Lichtquelle: schönes Wetter</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="250"/>
        <source>Light Source:Shade</source>
        <translation>Blendschirm</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="258"/>
        <source>Metering Mode:</source>
        <translation>Messmodus:</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="260"/>
        <source>Average</source>
        <translation>Durchschnitt</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="261"/>
        <source>Center weighted average</source>
        <translation>Gewichteter Mittelwert</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="273"/>
        <source>Exposure Program:</source>
        <translation>Belichtungsprogramm</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="349"/>
        <source>Latitude:%1</source>
        <translation>Breitengrad: %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="350"/>
        <source>Longitude:%1</source>
        <translation>Längengrad: %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="352"/>
        <source>Altitude:%1</source>
        <translation>Höhe: %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="262"/>
        <source>Spot</source>
        <translation>Spot</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="263"/>
        <source>Multi spot</source>
        <translation>Multispot</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="264"/>
        <source>Pattern</source>
        <translation>Muster</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="265"/>
        <source>Partial</source>
        <translation>Teilweise</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="266"/>
        <source>Other</source>
        <translation>Sonstiges</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="267"/>
        <source>Unknown (%1)</source>
        <translation>Unbekannt (%1)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="276"/>
        <source>Manual</source>
        <translation>Manuell</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="279"/>
        <source>Program (auto)</source>
        <translation>Programm (auto)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="282"/>
        <source>Aperture priority (semi-auto)</source>
        <translation>Zeitautomatik (halbautomatisch)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="285"/>
        <source>Shutter priority (semi-auto)</source>
        <translation>Blendenautomatik (halbautomatisch)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="288"/>
        <source>Creative Program (based towards depth of field)</source>
        <translation>Kreativ-Programm (auf Tiefenschärfe ausgerichtet)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="291"/>
        <source>Action program (based towards fast shutter speed)</source>
        <translation>Action-Programm (auf kurze Vershlusszeit ausgerichtet)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="294"/>
        <source>Portrait mode</source>
        <translation>Hochformat</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="297"/>
        <source>Landscape mode</source>
        <translation>Querformat</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="307"/>
        <source>Exposure Mode:Manual</source>
        <translation>Belichtungsmodus: manuell</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="309"/>
        <source>Exposure Mode:Auto bracketing</source>
        <translation>Belichtungsmodus: Belichtungsreihe</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="314"/>
        <source>Focus Range:</source>
        <translation>Fokusbereich:</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="317"/>
        <source>Macro</source>
        <translation>Makro</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="320"/>
        <source>Close</source>
        <translation>Nah</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="323"/>
        <source>Distant</source>
        <translation>Fern</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="338"/>
        <source>JPEG Process:Unknown</source>
        <translation>JPEG-Prozess: unbekannt</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="342"/>
        <source>JPEG Process:%1</source>
        <translation>JPEG-Prozess: %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="358"/>
        <source>JPEG Quality:%1</source>
        <translation>JPEG-Qualität: %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="364"/>
        <location filename="../jhead/jhead-api.cpp" line="375"/>
        <source>Comment:</source>
        <translation>Kommentar:</translation>
    </message>
    <message>
        <location filename="../globals.cpp" line="47"/>
        <source>%1 bytes</source>
        <translation>%1 Bytes</translation>
    </message>
    <message>
        <location filename="../globals.cpp" line="50"/>
        <source>%1 kB</source>
        <translation>%1 kB</translation>
    </message>
    <message>
        <location filename="../globals.cpp" line="53"/>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <location filename="../globals.cpp" line="55"/>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
</context>
<context>
    <name>RenameDialog</name>
    <message>
        <location filename="../qml/pages/RenameDialog.qml" line="40"/>
        <source>Rename</source>
        <translation>Umbenennen</translation>
    </message>
    <message>
        <location filename="../qml/pages/RenameDialog.qml" line="46"/>
        <source>Give a new name for</source>
        <translation>Neuen Namen eingeben für</translation>
    </message>
    <message>
        <location filename="../qml/pages/RenameDialog.qml" line="58"/>
        <location filename="../qml/pages/RenameDialog.qml" line="59"/>
        <source>New name</source>
        <translation>Neuer Name</translation>
    </message>
</context>
<context>
    <name>SearchPage</name>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="64"/>
        <source>Searching</source>
        <translation>Suche</translation>
    </message>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="75"/>
        <source>Settings</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="89"/>
        <source>Search %1</source>
        <translation>Suche %1</translation>
    </message>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="138"/>
        <source>%1 hits</source>
        <translation>%1 Treffer</translation>
    </message>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="266"/>
        <location filename="../qml/pages/SearchPage.qml" line="267"/>
        <location filename="../qml/pages/SearchPage.qml" line="347"/>
        <location filename="../qml/pages/SearchPage.qml" line="349"/>
        <source>Deleting</source>
        <translation>Lösche</translation>
    </message>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="282"/>
        <source>Go to containing folder</source>
        <translation>Enthaltenden Ordner öffnen</translation>
    </message>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="286"/>
        <source>Cut</source>
        <translation>Ausschneiden</translation>
    </message>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="290"/>
        <source>Copy</source>
        <translation>Kopieren</translation>
    </message>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="294"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="405"/>
        <source>Search</source>
        <translation>Suchen</translation>
    </message>
</context>
<context>
    <name>SearchWorker</name>
    <message>
        <location filename="../searchworker.cpp" line="19"/>
        <source>Search already in progress</source>
        <translation>Suche läuft bereits</translation>
    </message>
    <message>
        <location filename="../searchworker.cpp" line="23"/>
        <source>Bad search parameters</source>
        <translation>Falscher Suchbegriff</translation>
    </message>
</context>
<context>
    <name>SelectionPanel</name>
    <message>
        <location filename="../qml/components/SelectionPanel.qml" line="46"/>
        <location filename="../qml/components/SelectionPanel.qml" line="150"/>
        <source>%1 selected</source>
        <translation>%1 ausgewählt</translation>
    </message>
    <message>
        <location filename="../qml/components/SelectionPanel.qml" line="72"/>
        <location filename="../qml/components/SelectionPanel.qml" line="176"/>
        <source>%1 cut</source>
        <translation>%1 ausgeschnitten</translation>
    </message>
    <message>
        <location filename="../qml/components/SelectionPanel.qml" line="84"/>
        <location filename="../qml/components/SelectionPanel.qml" line="189"/>
        <source>%1 copied</source>
        <translation>%1 kopiert</translation>
    </message>
</context>
<context>
    <name>SettingsPage</name>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="21"/>
        <location filename="../qml/pages/SettingsPage.qml" line="99"/>
        <source>Settings</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="25"/>
        <source>Show folders first</source>
        <translation>Ordner zuerst zeigen</translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="30"/>
        <source>Show hidden files</source>
        <translation>Versteckte Dateien anzeigen</translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="37"/>
        <source>About File Browser</source>
        <translation>Über File Browser</translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="50"/>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="76"/>
        <source>File Browser is free and unencumbered software released into the public domain.</source>
        <translation>File Browser wurde lizenzfrei veröffentlich, und ist frei und unbeschränkt.</translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="77"/>
        <source>Read full text &gt;&gt;</source>
        <translation>Vollständigen Text lesen &gt;&gt;</translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="88"/>
        <source>The source code is available at</source>
        <translation>Der Quelltext ist verfügbar unter</translation>
    </message>
</context>
</TS>
