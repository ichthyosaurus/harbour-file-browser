<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr" sourcelanguage="en">
<context>
    <name>AboutPage</name>
    <message>
        <location filename="../qml/pages/AboutPage.qml" line="19"/>
        <source>Public Domain</source>
        <translation>Domaine public</translation>
    </message>
</context>
<context>
    <name>ConsoleModel</name>
    <message>
        <location filename="../consolemodel.cpp" line="101"/>
        <source>** crashed</source>
        <translation>** a connu un souci</translation>
    </message>
    <message>
        <location filename="../consolemodel.cpp" line="104"/>
        <source>** error: %1</source>
        <translation>** erreur : %1</translation>
    </message>
    <message>
        <location filename="../consolemodel.cpp" line="113"/>
        <source>** error</source>
        <translation>** erreur</translation>
    </message>
</context>
<context>
    <name>CreateFolderDialog</name>
    <message>
        <source>Create Folder</source>
        <translation type="vanished">Créer un dossier</translation>
    </message>
    <message>
        <location filename="../qml/pages/CreateFolderDialog.qml" line="30"/>
        <source>Create</source>
        <translation>Créer</translation>
    </message>
    <message>
        <location filename="../qml/pages/CreateFolderDialog.qml" line="36"/>
        <source>Create a new folder under</source>
        <translation>Créer un nouveau dossier dans</translation>
    </message>
    <message>
        <location filename="../qml/pages/CreateFolderDialog.qml" line="48"/>
        <location filename="../qml/pages/CreateFolderDialog.qml" line="49"/>
        <source>Folder name</source>
        <translation>Nom du dossier</translation>
    </message>
</context>
<context>
    <name>DirPopup</name>
    <message>
        <location filename="../qml/components/DirPopup.qml" line="22"/>
        <source>Root (%1)</source>
        <translation>Racine (%1)</translation>
    </message>
    <message>
        <location filename="../qml/components/DirPopup.qml" line="25"/>
        <source>Root</source>
        <translation>Racine</translation>
    </message>
    <message>
        <location filename="../qml/components/DirPopup.qml" line="32"/>
        <source>SD Card (%1)</source>
        <translation>Carte SD (%1)</translation>
    </message>
    <message>
        <location filename="../qml/components/DirPopup.qml" line="35"/>
        <source>SD Card</source>
        <translation>Carte SD</translation>
    </message>
    <message>
        <location filename="../qml/components/DirPopup.qml" line="81"/>
        <source>Android Storage not found</source>
        <translation>Stockage Android introuvable</translation>
    </message>
    <message>
        <location filename="../qml/components/DirPopup.qml" line="93"/>
        <source>SD Card not found</source>
        <translation>Carte SD introuvable</translation>
    </message>
    <message>
        <location filename="../qml/components/DirPopup.qml" line="100"/>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <location filename="../qml/components/DirPopup.qml" line="104"/>
        <source>Android Storage</source>
        <translation>Stockage Android</translation>
    </message>
</context>
<context>
    <name>DirectoryPage</name>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="40"/>
        <source>Settings</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="44"/>
        <source>Create Folder</source>
        <translation>Créer un dossier</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="55"/>
        <source>Search</source>
        <translation>Recherche</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="60"/>
        <source>Paste</source>
        <translation>Coller</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="71"/>
        <location filename="../qml/pages/DirectoryPage.qml" line="78"/>
        <source>Copying</source>
        <translation>Copie</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="71"/>
        <location filename="../qml/pages/DirectoryPage.qml" line="78"/>
        <source>Moving</source>
        <translation>Déplacement</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="201"/>
        <location filename="../qml/pages/DirectoryPage.qml" line="202"/>
        <location filename="../qml/pages/DirectoryPage.qml" line="275"/>
        <location filename="../qml/pages/DirectoryPage.qml" line="277"/>
        <source>Deleting</source>
        <translation>Suppression</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="217"/>
        <source>Cut</source>
        <translation>Couper</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="221"/>
        <source>Copy</source>
        <translation>Copier</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="225"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="232"/>
        <source>Properties</source>
        <translation>Propriétés</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="245"/>
        <source>No files</source>
        <translation>Aucun fichier</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="319"/>
        <source>Trying to move between phone and SD Card? It does not work, try copying.</source>
        <translation>Souhaitez-vous basculer entre le téléphone et le carte SD ? Si cela échoue essayez de copier les fichiers.</translation>
    </message>
    <message>
        <location filename="../qml/pages/DirectoryPage.qml" line="321"/>
        <source>Perhaps the storage is full?</source>
        <translation>L&apos;espace de stockage est peut-être plein ?</translation>
    </message>
</context>
<context>
    <name>Engine</name>
    <message>
        <location filename="../engine.cpp" line="110"/>
        <source>Destination does not exist</source>
        <translation>La destination n&apos;existe pas</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="121"/>
        <source>Cannot overwrite itself</source>
        <translation>Impossible d&apos;écraser le fichier avec le lui-même</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="127"/>
        <source>Cannot move/copy to itself</source>
        <translation>Impossible de déplacer/copier vers lui-même</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="102"/>
        <source>No files to paste</source>
        <translation>Aucun fichier à coller</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="272"/>
        <source>File does not exist</source>
        <translation>Le fichier n&apos;existe pas</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="274"/>
        <source>Broken symbolic link</source>
        <translation>Lien symbolique cassé</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="279"/>
        <source>Cannot read this type of file</source>
        <translation>Impossible de lire ce type de fichier</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="285"/>
        <source>No permission to read the file</source>
        <translation>Vous n&apos;avez pas la permission de lire ce fichier</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="289"/>
        <location filename="../engine.cpp" line="295"/>
        <source>Error reading file</source>
        <translation>Erreur de lecture du fichier</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="298"/>
        <source>Empty file</source>
        <translation>Fichier vide</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="324"/>
        <location filename="../engine.cpp" line="325"/>
        <source>--- Binary file preview clipped at %1 kB ---</source>
        <translation>--- Aperçu du fichier binaire coupé à %1 ko ---</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="344"/>
        <source>--- Text file preview clipped at %1 lines ---</source>
        <translation>--- Aperçu du fichier binaire coupé ligne %1 ---</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="346"/>
        <source>--- Text file preview clipped at %1 kB ---</source>
        <translation>--- Aperçu du fichier texte coupé à %1 ko ---</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="358"/>
        <source>No permissions to create %1</source>
        <translation>Vous n&apos;avez pas la permission de créer %1</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="376"/>
        <source>Cannot rename %1</source>
        <translation>Impossible de renommer %1</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="399"/>
        <source>Cannot change permissions</source>
        <translation>Impossible de changer les permissions</translation>
    </message>
    <message>
        <location filename="../engine.cpp" line="360"/>
        <source>Cannot create folder %1</source>
        <translation>Impossible de créer le dossier %1</translation>
    </message>
</context>
<context>
    <name>FileData</name>
    <message>
        <location filename="../filedata.cpp" line="102"/>
        <source>File does not exist</source>
        <translation>Le fichier n&apos;existe pas</translation>
    </message>
    <message>
        <location filename="../filedata.cpp" line="136"/>
        <source>block device</source>
        <translation>dispositif de blocage</translation>
    </message>
    <message>
        <location filename="../filedata.cpp" line="140"/>
        <source>character device</source>
        <translation>dispositif de caractère</translation>
    </message>
    <message>
        <location filename="../filedata.cpp" line="144"/>
        <source>pipe</source>
        <translation>pipe</translation>
    </message>
    <message>
        <location filename="../filedata.cpp" line="148"/>
        <source>socket</source>
        <translation>socket</translation>
    </message>
    <message>
        <location filename="../filedata.cpp" line="152"/>
        <source>folder</source>
        <translation>dossier</translation>
    </message>
    <message>
        <location filename="../filedata.cpp" line="157"/>
        <source>unknown</source>
        <translation>inconnu</translation>
    </message>
    <message>
        <location filename="../filedata.cpp" line="180"/>
        <source>Image Size</source>
        <translation>Taille de l&apos;image</translation>
    </message>
</context>
<context>
    <name>FileModel</name>
    <message>
        <location filename="../filemodel.cpp" line="71"/>
        <source>dir-link</source>
        <translation>dir-link</translation>
    </message>
    <message>
        <location filename="../filemodel.cpp" line="72"/>
        <source>dir</source>
        <translation>dir</translation>
    </message>
    <message>
        <location filename="../filemodel.cpp" line="300"/>
        <location filename="../filemodel.cpp" line="338"/>
        <source>Folder does not exist</source>
        <translation>Le dossier n&apos;existe pas</translation>
    </message>
    <message>
        <location filename="../filemodel.cpp" line="304"/>
        <location filename="../filemodel.cpp" line="344"/>
        <source>No permission to read the folder</source>
        <translation>Vous n&apos;avez pas la permission de lire le dossier</translation>
    </message>
</context>
<context>
    <name>FilePage</name>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="26"/>
        <source>Install launched</source>
        <translation>Installation lancée</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="27"/>
        <source>If nothing happens, then the package is probably faulty.</source>
        <translation>Si rien ne se passe il est probable que le paquet soit défectueux.</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="31"/>
        <source>Open successful</source>
        <translation>Ouvert avec succès</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="32"/>
        <source>Sometimes the application stays in the background</source>
        <translation>Parfois l&apos;application reste en arrière-plan</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="34"/>
        <source>Internal error</source>
        <translation>Erreur interne</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="37"/>
        <source>File not found</source>
        <translation>Fichier non trouvé</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="40"/>
        <source>No application to open the file</source>
        <translation>Aucune application pour ouvrir ce fichier</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="41"/>
        <source>xdg-open found no preferred application</source>
        <translation>xdg-open n&apos;a pas trouvé d&apos;application favorite</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="43"/>
        <source>Action failed</source>
        <translation>L&apos;action a échoué</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="46"/>
        <source>xdg-open not found</source>
        <translation>xdg-open introuvable</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="49"/>
        <source>xdg-open crash?</source>
        <translation>xdg-open a planté ?</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="52"/>
        <source>xdg-open error</source>
        <translation>Erreur de xdg-open</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="65"/>
        <source>Change Permissions</source>
        <translation>Changer les permissions</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="78"/>
        <source>Rename</source>
        <translation>Renommer</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="92"/>
        <source>View Contents</source>
        <translation>Voir le contenu</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="99"/>
        <source>Install</source>
        <translation>Installer</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="99"/>
        <source>Open</source>
        <translation>Ouvrir</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="103"/>
        <source>File cannot be opened</source>
        <translation>Impossible d&apos;ouvrir le fichier</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="104"/>
        <source>This type of file cannot be opened.</source>
        <translation>Ce type de fichier n&apos;est pas ouvrable.</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="112"/>
        <source>Go to Target</source>
        <translation>Aller à la destination</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="236"/>
        <source>Location</source>
        <translation>Emplacement</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="240"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="242"/>
        <source>Link to %1</source>
        <translation>Lien ver %1</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="246"/>
        <source>Size</source>
        <translation>Taille</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="250"/>
        <source>Permissions</source>
        <translation>Permissions</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="254"/>
        <source>Owner</source>
        <translation>Propiétaire</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="258"/>
        <source>Group</source>
        <translation>Groupe</translation>
    </message>
    <message>
        <location filename="../qml/pages/FilePage.qml" line="262"/>
        <source>Last modified</source>
        <translation>Dernière modification</translation>
    </message>
    <message>
        <source>Created</source>
        <translation type="vanished">Créé</translation>
    </message>
</context>
<context>
    <name>FileWorker</name>
    <message>
        <location filename="../fileworker.cpp" line="20"/>
        <location filename="../fileworker.cpp" line="36"/>
        <location filename="../fileworker.cpp" line="53"/>
        <source>File operation already in progress</source>
        <translation>Opération sur le fichier déjà en cours</translation>
    </message>
    <message>
        <location filename="../fileworker.cpp" line="91"/>
        <source>Empty filename</source>
        <translation>Nombre de dossiers vides</translation>
    </message>
    <message>
        <location filename="../fileworker.cpp" line="102"/>
        <source>File not found</source>
        <translation>Fichier introuvable</translation>
    </message>
    <message>
        <location filename="../fileworker.cpp" line="115"/>
        <source>Folder delete failed</source>
        <translation>Échec lors de la suppression du dossier</translation>
    </message>
    <message>
        <location filename="../fileworker.cpp" line="137"/>
        <location filename="../fileworker.cpp" line="188"/>
        <location filename="../fileworker.cpp" line="284"/>
        <location filename="../fileworker.cpp" line="300"/>
        <source>Cancelled</source>
        <translation>Annulé</translation>
    </message>
    <message>
        <location filename="../fileworker.cpp" line="269"/>
        <source>Source folder does not exist</source>
        <translation>Le dossier source n&apos;existe pas</translation>
    </message>
    <message>
        <location filename="../fileworker.cpp" line="276"/>
        <source>Cannot create target folder %1</source>
        <translation>Impossible de créer le dossier de destination %1</translation>
    </message>
</context>
<context>
    <name>OverwriteDialog</name>
    <message>
        <location filename="../qml/pages/OverwriteDialog.qml" line="27"/>
        <source>Replace?</source>
        <translation>Remplacer ?</translation>
    </message>
    <message>
        <location filename="../qml/pages/OverwriteDialog.qml" line="28"/>
        <source>Replace</source>
        <translation>Remplacer</translation>
    </message>
    <message>
        <location filename="../qml/pages/OverwriteDialog.qml" line="32"/>
        <source>These files or folders already exist:</source>
        <translation>Ces fichiers et répertoires existent déjà :</translation>
    </message>
</context>
<context>
    <name>PermissionsDialog</name>
    <message>
        <source>Change Permissions</source>
        <translation type="vanished">Changer les permissions</translation>
    </message>
    <message>
        <location filename="../qml/pages/PermissionsDialog.qml" line="56"/>
        <source>Change</source>
        <translation>Changer</translation>
    </message>
    <message>
        <location filename="../qml/pages/PermissionsDialog.qml" line="62"/>
        <source>Change permissions for</source>
        <translation>Changer les permissions pour</translation>
    </message>
    <message>
        <location filename="../qml/pages/PermissionsDialog.qml" line="82"/>
        <source>Read</source>
        <translation>Lecture</translation>
    </message>
    <message>
        <location filename="../qml/pages/PermissionsDialog.qml" line="90"/>
        <source>Write</source>
        <translation>Écriture</translation>
    </message>
    <message>
        <location filename="../qml/pages/PermissionsDialog.qml" line="97"/>
        <source>Execute</source>
        <translation>Executer</translation>
    </message>
    <message>
        <location filename="../qml/pages/PermissionsDialog.qml" line="118"/>
        <source>Owner</source>
        <translation>Propiétaire</translation>
    </message>
    <message>
        <location filename="../qml/pages/PermissionsDialog.qml" line="156"/>
        <source>Group</source>
        <translation>Groupe</translation>
    </message>
    <message>
        <location filename="../qml/pages/PermissionsDialog.qml" line="189"/>
        <source>Others</source>
        <translation>Autres</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="120"/>
        <source>Make:%1</source>
        <translation>Fabriquant : %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="121"/>
        <source>Model:%1</source>
        <translation>Modèle : %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="124"/>
        <source>Date/Time:%1</source>
        <translation>Date/Heure : %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="131"/>
        <source>Orientation:%1</source>
        <translation>Orientation : %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="136"/>
        <source>Color/BW:Black and White</source>
        <translation>Coleur/NB : Noir et blanc</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="143"/>
        <source>(Strobe light not detected)</source>
        <translation>(lumière stroboscopique non détectée)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="144"/>
        <source>(Strobe light detected) </source>
        <translation>(lumière stroboscopique détectée)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="145"/>
        <source>(Manual)</source>
        <translation>(Manuel)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="146"/>
        <source>(Manual, return light not detected)</source>
        <translation>(Manuel, flash non détecté)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="148"/>
        <location filename="../jhead/jhead-api.cpp" line="166"/>
        <source>(Auto)</source>
        <translation>(Auto)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="149"/>
        <source>(Auto, return light not detected)</source>
        <translation>(Auto, flash non détecté)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="150"/>
        <source>(Auto, return light detected)</source>
        <translation>(Auto, flash détecté)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="151"/>
        <source>(Red eye reduction mode)</source>
        <translation>(Mode réduction des yeux rouges)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="152"/>
        <source>(Red eye reduction mode return light not detected)</source>
        <translation>(Mode réduction des yeux rouges avec le flash non détecté)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="147"/>
        <source>(Manual, return light detected)</source>
        <translation>(Manuel, flash détecté)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="153"/>
        <source>(Red eye reduction mode return light detected)</source>
        <translation>(Mode réduction des yeux rouges avec le flash détecté)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="154"/>
        <source>(Manual, red eye reduction mode)</source>
        <translation>(Manuel, mode réduction des yeux rouges)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="155"/>
        <source>(Manual, red eye reduction mode, return light not detected)</source>
        <translation>(Manuel, mode réduction des yeux rouges, flash non détecté)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="156"/>
        <source>(Red eye reduction mode, return light detected)</source>
        <translation>(mode réduction des yeux rouges, flash détecté)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="157"/>
        <source>(Auto, red eye reduction mode)</source>
        <translation>(Auto, mode réduction des yeux rouges)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="158"/>
        <source>(Auto, red eye reduction mode, return light not detected)</source>
        <translation>(Auto, mode réduction des yeux rouges, flash non détecté)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="159"/>
        <source>(Auto, red eye reduction mode, return light detected)</source>
        <translation>(Auto, mode réduction des yeux rouges, flash détecté)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="161"/>
        <source>Flash:Yes</source>
        <translation>Flash : oui</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="168"/>
        <source>Flash:No</source>
        <translation>Flash : non</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="174"/>
        <source>Focal Length:%1mm</source>
        <translation>Longitude focale : %1mm</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="176"/>
        <source>(35mm equivalent: %1mm)</source>
        <translation>(Équivalente à 35mm : %1mm)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="183"/>
        <source>Digital Zoom:%1x</source>
        <translation>Zoom numérique : %1x</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="187"/>
        <source>CCD Width:%1</source>
        <translation>Largeur CCD : %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="193"/>
        <location filename="../jhead/jhead-api.cpp" line="195"/>
        <source>Exposure Time:%1</source>
        <translation>Temps d&apos;exposition : %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="198"/>
        <source>(1/%1)</source>
        <translation>(1/%1)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="203"/>
        <source>Aperture:f/%1</source>
        <translation>Ouverture : f/%1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="207"/>
        <source>Focus Distance:Infinite</source>
        <translation>Mise au point : infinie</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="209"/>
        <source>Focus Distance:%1m</source>
        <translation>Mise au point : %1m</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="214"/>
        <source>ISO Equivalent:%1</source>
        <translation>ISO : %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="220"/>
        <source>Exposure Bias:%1</source>
        <translation>Compensation de l&apos;exposition:%1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="225"/>
        <source>White Balance:Manual</source>
        <translation>Balance des blancs : manuelle</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="228"/>
        <source>White Balance:Auto</source>
        <translation>Balance des blancs : auto</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="235"/>
        <source>Light Source:Daylight</source>
        <translation>Source de lumière : naturelle</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="238"/>
        <source>Light Source:Fluorescent</source>
        <translation>Source de lumière : tube fluorescent</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="241"/>
        <source>Light Source:Incandescent</source>
        <translation>Source de lumière : ampoule incandescente</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="244"/>
        <source>Light Source:Flash</source>
        <translation>Source de lumière : flash</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="247"/>
        <source>Light Source:Fine weather</source>
        <translation>Source de lumière : journée ensoleillée</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="250"/>
        <source>Light Source:Shade</source>
        <translation>Source de lumière : nuageux</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="258"/>
        <source>Metering Mode:</source>
        <translation>Mode de mesure : </translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="260"/>
        <source>Average</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="261"/>
        <source>Center weighted average</source>
        <translation>Centre moyenne pondérée</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="273"/>
        <source>Exposure Program:</source>
        <translation>Programme d&apos;exposition : </translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="349"/>
        <source>Latitude:%1</source>
        <translation>Latitude : %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="350"/>
        <source>Longitude:%1</source>
        <translation>Longitude : %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="352"/>
        <source>Altitude:%1</source>
        <translation>Altitude : %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="262"/>
        <source>Spot</source>
        <translation>Point</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="263"/>
        <source>Multi spot</source>
        <translation>Matrice</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="264"/>
        <source>Pattern</source>
        <translation>Patron</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="265"/>
        <source>Partial</source>
        <translation>Partiel</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="266"/>
        <source>Other</source>
        <translation>Autre</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="267"/>
        <source>Unknown (%1)</source>
        <translation>Inconnu (%1)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="276"/>
        <source>Manual</source>
        <translation>Manuel</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="279"/>
        <source>Program (auto)</source>
        <translation>Programme (auto)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="282"/>
        <source>Aperture priority (semi-auto)</source>
        <translation>Priorité à l&apos;ouverture (semi-auto)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="285"/>
        <source>Shutter priority (semi-auto)</source>
        <translation>Priorité à l&apos;obturateur (semi-auto)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="288"/>
        <source>Creative Program (based towards depth of field)</source>
        <translation>Mode créatif (en s&apos;appuyant sur le profondeur de champ)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="291"/>
        <source>Action program (based towards fast shutter speed)</source>
        <translation>Mode action (en s&apos;appuyant sur la vitesse d&apos;obturation)</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="294"/>
        <source>Portrait mode</source>
        <translation>Mode portrait</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="297"/>
        <source>Landscape mode</source>
        <translation>Mode paysage</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="307"/>
        <source>Exposure Mode:Manual</source>
        <translation>Mode d&apos;exposition : Manuel</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="309"/>
        <source>Exposure Mode:Auto bracketing</source>
        <translation>Mode d&apos;exposition : Auto</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="314"/>
        <source>Focus Range:</source>
        <translation>Plage de mise au point : </translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="317"/>
        <source>Macro</source>
        <translation>Macro</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="320"/>
        <source>Close</source>
        <translation>Proche</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="323"/>
        <source>Distant</source>
        <translation>Distant</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="338"/>
        <source>JPEG Process:Unknown</source>
        <translation>Processus JPEG : inconnu</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="342"/>
        <source>JPEG Process:%1</source>
        <translation>Processus JPEG : %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="358"/>
        <source>JPEG Quality:%1</source>
        <translation>Qualité JPEG : %1</translation>
    </message>
    <message>
        <location filename="../jhead/jhead-api.cpp" line="364"/>
        <location filename="../jhead/jhead-api.cpp" line="375"/>
        <source>Comment:</source>
        <translation>Commentaire : </translation>
    </message>
    <message>
        <location filename="../globals.cpp" line="47"/>
        <source>%1 bytes</source>
        <translation>%1 octets</translation>
    </message>
    <message>
        <location filename="../globals.cpp" line="50"/>
        <source>%1 kB</source>
        <translation>%1 ko</translation>
    </message>
    <message>
        <location filename="../globals.cpp" line="53"/>
        <source>%1 MB</source>
        <translation>%1 Mo</translation>
    </message>
    <message>
        <location filename="../globals.cpp" line="55"/>
        <source>%1 GB</source>
        <translation>%1 Go</translation>
    </message>
</context>
<context>
    <name>RenameDialog</name>
    <message>
        <location filename="../qml/pages/RenameDialog.qml" line="40"/>
        <source>Rename</source>
        <translation>Renommer</translation>
    </message>
    <message>
        <location filename="../qml/pages/RenameDialog.qml" line="46"/>
        <source>Give a new name for</source>
        <translation>Attribuer un nouveau nom à</translation>
    </message>
    <message>
        <location filename="../qml/pages/RenameDialog.qml" line="58"/>
        <location filename="../qml/pages/RenameDialog.qml" line="59"/>
        <source>New name</source>
        <translation>Nouveau nom</translation>
    </message>
</context>
<context>
    <name>SearchPage</name>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="64"/>
        <source>Searching</source>
        <translation>Recherche en cours</translation>
    </message>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="75"/>
        <source>Settings</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="89"/>
        <source>Search %1</source>
        <translation>Examiner %1</translation>
    </message>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="138"/>
        <source>%1 hits</source>
        <translation>%1 résultats</translation>
    </message>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="266"/>
        <location filename="../qml/pages/SearchPage.qml" line="267"/>
        <location filename="../qml/pages/SearchPage.qml" line="347"/>
        <location filename="../qml/pages/SearchPage.qml" line="349"/>
        <source>Deleting</source>
        <translation>Suppression</translation>
    </message>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="282"/>
        <source>Go to containing folder</source>
        <translation>Aller au dossier contenant le fichier</translation>
    </message>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="286"/>
        <source>Cut</source>
        <translation>Couper</translation>
    </message>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="290"/>
        <source>Copy</source>
        <translation>Copier</translation>
    </message>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="294"/>
        <source>Delete</source>
        <translation>Effacer</translation>
    </message>
    <message>
        <location filename="../qml/pages/SearchPage.qml" line="405"/>
        <source>Search</source>
        <translation>Recherche</translation>
    </message>
</context>
<context>
    <name>SearchWorker</name>
    <message>
        <location filename="../searchworker.cpp" line="19"/>
        <source>Search already in progress</source>
        <translation>La recherche est déjà en cours</translation>
    </message>
    <message>
        <location filename="../searchworker.cpp" line="23"/>
        <source>Bad search parameters</source>
        <translation>Paramètres de recherche incorrects</translation>
    </message>
</context>
<context>
    <name>SelectionPanel</name>
    <message>
        <location filename="../qml/components/SelectionPanel.qml" line="46"/>
        <location filename="../qml/components/SelectionPanel.qml" line="150"/>
        <source>%1 selected</source>
        <translation>%1 sélectionné</translation>
    </message>
    <message>
        <location filename="../qml/components/SelectionPanel.qml" line="72"/>
        <location filename="../qml/components/SelectionPanel.qml" line="176"/>
        <source>%1 cut</source>
        <translation>%1 coupé</translation>
    </message>
    <message>
        <location filename="../qml/components/SelectionPanel.qml" line="84"/>
        <location filename="../qml/components/SelectionPanel.qml" line="189"/>
        <source>%1 copied</source>
        <translation>%1 copié</translation>
    </message>
</context>
<context>
    <name>SettingsPage</name>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="21"/>
        <location filename="../qml/pages/SettingsPage.qml" line="99"/>
        <source>Settings</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="25"/>
        <source>Show folders first</source>
        <translation>Afficher les dossiers en premier</translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="30"/>
        <source>Show hidden files</source>
        <translation>Afficher les fichiers cachés</translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="37"/>
        <source>About File Browser</source>
        <translation>À propos de File Browser</translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="50"/>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="76"/>
        <source>File Browser is free and unencumbered software released into the public domain.</source>
        <translation>File Browser est libre, ouvert et publié dans le domaine public.</translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="77"/>
        <source>Read full text &gt;&gt;</source>
        <translation>Lire le texte complet &gt;&gt;</translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="88"/>
        <source>The source code is available at</source>
        <translation>Le code source est disponible sur</translation>
    </message>
</context>
</TS>
